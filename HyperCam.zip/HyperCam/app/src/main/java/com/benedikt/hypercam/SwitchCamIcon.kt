package com.benedikt.hypercam

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import kotlin.math.cos
import kotlin.math.sin

/** Ikonka přepnutí kamery: dvě kruhové šipky, kreslené přímo (žádný emoji, sedí do UI). */
@Composable
fun SwitchCamIcon(modifier: Modifier = Modifier, tint: Color = Color.White) {
    Canvas(modifier) {
        val w = size.minDimension
        val c = center
        val r = w * 0.32f
        val sw = w * 0.085f
        for (k in 0..1) {
            val start = 200f + 180f * k
            drawArc(
                color = tint, startAngle = start, sweepAngle = 120f, useCenter = false,
                topLeft = Offset(c.x - r, c.y - r), size = Size(2 * r, 2 * r),
                style = Stroke(width = sw, cap = StrokeCap.Round)
            )
            // hrot šipky na konci oblouku
            val a = Math.toRadians((start + 120f).toDouble())
            val nx = cos(a).toFloat(); val ny = sin(a).toFloat()
            val tx = -ny; val ty = nx
            val tip = Offset(c.x + r * nx, c.y + r * ny)
            val len = w * 0.2f
            val head = Path().apply {
                moveTo(tip.x + tx * len, tip.y + ty * len)
                lineTo(tip.x + nx * len * 0.7f, tip.y + ny * len * 0.7f)
                lineTo(tip.x - nx * len * 0.7f, tip.y - ny * len * 0.7f)
                close()
            }
            drawPath(head, tint)
        }
    }
}
