package com.benedikt.hypercam

import android.graphics.SurfaceTexture
import android.opengl.*
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.view.Surface
import androidx.camera.core.CameraEffect
import androidx.camera.core.SurfaceOutput
import androidx.camera.core.SurfaceProcessor
import androidx.camera.core.SurfaceRequest
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executor

/** Efekt pro náhled + video: stejný Apple look jako u fotek, ale na GPU v reálném čase. */
fun createAppleEffect(): CameraEffect {
    val proc = AppleVideoProcessor()
    return object : CameraEffect(
        PREVIEW or VIDEO_CAPTURE, proc.executor, proc,
        { e -> Log.e("HyperCam", "Effect error", e) }
    ) {}
}

class AppleVideoProcessor : SurfaceProcessor {
    private val thread = HandlerThread("apple-gl").also { it.start() }
    private val handler = Handler(thread.looper)
    val executor = Executor { handler.post(it) }

    private var dpy: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var ctx: EGLContext = EGL14.EGL_NO_CONTEXT
    private var recCfg: EGLConfig? = null
    private var pbuf: EGLSurface = EGL14.EGL_NO_SURFACE
    private var program = 0
    private var aPos = 0
    private var aTex = 0
    private var uMat = 0
    private val outputs = HashMap<SurfaceOutput, EGLSurface>()
    private val texMat = FloatArray(16)
    private val surfMat = FloatArray(16)
    private val quad = ByteBuffer.allocateDirect(16 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
        put(floatArrayOf(-1f, -1f, 0f, 0f, 1f, -1f, 1f, 0f, -1f, 1f, 0f, 1f, 1f, 1f, 1f, 1f))
    }

    private fun initGl() {
        if (ctx != EGL14.EGL_NO_CONTEXT) return
        dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val v = IntArray(2)
        EGL14.eglInitialize(dpy, v, 0, v, 1)
        val n = IntArray(1)
        val base = intArrayOf(
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT)
        val cfgA = arrayOfNulls<EGLConfig>(1)
        // config pro okna (encoder / náhled) – recordable
        EGL14.eglChooseConfig(dpy, base + intArrayOf(0x3142, 1, EGL14.EGL_NONE), 0, cfgA, 0, 1, n, 0)
        recCfg = cfgA[0]
        // config pro pbuffer
        val cfgP = arrayOfNulls<EGLConfig>(1)
        EGL14.eglChooseConfig(dpy, base + intArrayOf(EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT, EGL14.EGL_NONE),
            0, cfgP, 0, 1, n, 0)
        ctx = EGL14.eglCreateContext(dpy, recCfg, EGL14.EGL_NO_CONTEXT,
            intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0)
        pbuf = EGL14.eglCreatePbufferSurface(dpy, cfgP[0],
            intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE), 0)
        EGL14.eglMakeCurrent(dpy, pbuf, pbuf, ctx)

        val vs = """
            attribute vec4 aPos; attribute vec2 aTex; uniform mat4 uMat; varying vec2 vTex;
            void main(){ gl_Position = aPos; vTex = (uMat * vec4(aTex, 0.0, 1.0)).xy; }"""
        val fs = """
            #extension GL_OES_EGL_image_external : require
            precision mediump float; varying vec2 vTex; uniform samplerExternalOES uTex;
            void main(){
              vec3 c = texture2D(uTex, vTex).rgb;
              c = c + 0.45 * c * (1.0 - c) * (2.0 * c - 1.0);
              c = 0.015 + c * 0.985;
              float l = dot(c, vec3(0.299, 0.587, 0.114));
              c = l + (c - l) * 1.12;
              c *= vec3(1.02, 1.0, 0.975);
              gl_FragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
            }"""
        program = GLES20.glCreateProgram().also {
            GLES20.glAttachShader(it, shader(GLES20.GL_VERTEX_SHADER, vs))
            GLES20.glAttachShader(it, shader(GLES20.GL_FRAGMENT_SHADER, fs))
            GLES20.glLinkProgram(it)
        }
        aPos = GLES20.glGetAttribLocation(program, "aPos")
        aTex = GLES20.glGetAttribLocation(program, "aTex")
        uMat = GLES20.glGetUniformLocation(program, "uMat")
    }

    private fun shader(type: Int, src: String): Int = GLES20.glCreateShader(type).also {
        GLES20.glShaderSource(it, src); GLES20.glCompileShader(it)
    }

    override fun onInputSurface(request: SurfaceRequest) {
        handler.post {
            initGl()
            val t = IntArray(1)
            GLES20.glGenTextures(1, t, 0)
            val texId = t[0]
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texId)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
            val st = SurfaceTexture(texId)
            st.setDefaultBufferSize(request.resolution.width, request.resolution.height)
            val surface = Surface(st)
            st.setOnFrameAvailableListener({ draw(st, texId) }, handler)
            request.provideSurface(surface, executor) {
                st.setOnFrameAvailableListener(null)
                st.release(); surface.release()
                GLES20.glDeleteTextures(1, intArrayOf(texId), 0)
            }
        }
    }

    override fun onOutputSurface(output: SurfaceOutput) {
        handler.post {
            initGl()
            val surface = output.getSurface(executor) { _ ->
                outputs.remove(output)?.let { EGL14.eglDestroySurface(dpy, it) }
                output.close()
            }
            outputs[output] = EGL14.eglCreateWindowSurface(dpy, recCfg, surface, intArrayOf(EGL14.EGL_NONE), 0)
        }
    }

    private fun draw(st: SurfaceTexture, texId: Int) {
        try {
            st.updateTexImage()
        } catch (e: Exception) { return }
        st.getTransformMatrix(texMat)
        val ts = st.timestamp
        for ((out, es) in outputs) {
            EGL14.eglMakeCurrent(dpy, es, es, ctx)
            out.updateTransformMatrix(surfMat, texMat)
            GLES20.glViewport(0, 0, out.size.width, out.size.height)
            GLES20.glUseProgram(program)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texId)
            GLES20.glUniformMatrix4fv(uMat, 1, false, surfMat, 0)
            quad.position(0)
            GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 16, quad)
            GLES20.glEnableVertexAttribArray(aPos)
            quad.position(2)
            GLES20.glVertexAttribPointer(aTex, 2, GLES20.GL_FLOAT, false, 16, quad)
            GLES20.glEnableVertexAttribArray(aTex)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            EGLExt.eglPresentationTimeANDROID(dpy, es, ts)
            EGL14.eglSwapBuffers(dpy, es)
        }
        EGL14.eglMakeCurrent(dpy, pbuf, pbuf, ctx)
    }
}
