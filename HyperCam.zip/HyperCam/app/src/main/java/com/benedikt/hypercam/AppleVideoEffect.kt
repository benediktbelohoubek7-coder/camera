package com.benedikt.hypercam

import android.graphics.SurfaceTexture
import android.opengl.*
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.view.Surface
import androidx.camera.core.CameraEffect
import androidx.camera.core.SurfaceOutput
import androidx.camera.core.SurfaceProcessor
import androidx.camera.core.SurfaceRequest
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executor

/** Efekt pro náhled + video: Apple look na GPU v reálném čase. Chyby se hlásí přes onError. */
fun createAppleEffect(onError: (String) -> Unit): CameraEffect {
    val proc = AppleVideoProcessor(onError)
    return object : CameraEffect(
        VIDEO_CAPTURE, proc.executor, proc,
        { e -> Log.e("HyperCam", "Effect error", e); onError("Efekt: ${e.message}") }
    ) {}
}

class AppleVideoProcessor(private val onError: (String) -> Unit) : SurfaceProcessor {
    private val thread = HandlerThread("apple-gl").also { it.start() }
    private val handler = Handler(thread.looper)
    val executor = Executor { handler.post(it) }

    private var dpy: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var ctx: EGLContext = EGL14.EGL_NO_CONTEXT
    private var cfg: EGLConfig? = null
    private var pbuf: EGLSurface = EGL14.EGL_NO_SURFACE
    private var program = 0
    private var aPos = 0
    private var aTex = 0
    private var uMat = 0
    private val outputs = HashMap<SurfaceOutput, EGLSurface>()
    private val texMat = FloatArray(16)
    private val surfMat = FloatArray(16)
    private val quad = ByteBuffer.allocateDirect(16 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
        put(floatArrayOf(-1f, -1f, 0f, 0f, 1f, -1f, 1f, 0f, -1f, 1f, 0f, 1f, 1f, 1f, 1f, 1f))
    }

    private fun fail(msg: String) { Log.e("HyperCam", msg); AppleDebug.last = msg; onError(msg) }

    private fun initGl(): Boolean {
        if (ctx != EGL14.EGL_NO_CONTEXT) return true
        dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val v = IntArray(2)
        if (!EGL14.eglInitialize(dpy, v, 0, v, 1)) { fail("EGL init selhal"); return false }
        val base = intArrayOf(
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT,
            EGL14.EGL_SURFACE_TYPE, EGL14.EGL_WINDOW_BIT or EGL14.EGL_PBUFFER_BIT)
        val c = arrayOfNulls<EGLConfig>(1)
        val n = IntArray(1)
        var ok = EGL14.eglChooseConfig(dpy, base + intArrayOf(0x3142, 1, EGL14.EGL_NONE), 0, c, 0, 1, n, 0) && n[0] > 0
        if (!ok) ok = EGL14.eglChooseConfig(dpy, base + intArrayOf(EGL14.EGL_NONE), 0, c, 0, 1, n, 0) && n[0] > 0
        if (!ok) { fail("EGL config nenalezen"); return false }
        cfg = c[0]
        ctx = EGL14.eglCreateContext(dpy, cfg, EGL14.EGL_NO_CONTEXT,
            intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0)
        pbuf = EGL14.eglCreatePbufferSurface(dpy, cfg,
            intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE), 0)
        if (!EGL14.eglMakeCurrent(dpy, pbuf, pbuf, ctx)) { fail("EGL makeCurrent selhal"); return false }

        val vs = "attribute vec4 aPos; attribute vec2 aTex; uniform mat4 uMat; varying vec2 vTex;\n" +
            "void main(){ gl_Position = aPos; vTex = (uMat * vec4(aTex, 0.0, 1.0)).xy; }\n"
        val fs = "#extension GL_OES_EGL_image_external : require\n" +
            "precision mediump float; varying vec2 vTex; uniform samplerExternalOES uTex;\n" +
            "void main(){\n" +
            "  vec3 c = texture2D(uTex, vTex).rgb;\n" +
            "  c = c + 0.45 * c * (1.0 - c) * (2.0 * c - 1.0);\n" +
            "  c = 0.015 + c * 0.985;\n" +
            "  float l = dot(c, vec3(0.299, 0.587, 0.114));\n" +
            "  c = l + (c - l) * 1.12;\n" +
            "  c *= vec3(1.02, 1.0, 0.975);\n" +
            "  gl_FragColor = vec4(clamp(c, 0.0, 1.0), 1.0);\n" +
            "}\n"
        val vsh = shader(GLES20.GL_VERTEX_SHADER, vs) ?: return false
        val fsh = shader(GLES20.GL_FRAGMENT_SHADER, fs) ?: return false
        program = GLES20.glCreateProgram()
        GLES20.glAttachShader(program, vsh)
        GLES20.glAttachShader(program, fsh)
        GLES20.glLinkProgram(program)
        val st = IntArray(1)
        GLES20.glGetProgramiv(program, GLES20.GL_LINK_STATUS, st, 0)
        if (st[0] == 0) { fail("Shader link: " + GLES20.glGetProgramInfoLog(program)); return false }
        aPos = GLES20.glGetAttribLocation(program, "aPos")
        aTex = GLES20.glGetAttribLocation(program, "aTex")
        uMat = GLES20.glGetUniformLocation(program, "uMat")
        return true
    }

    private fun shader(type: Int, src: String): Int? {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src); GLES20.glCompileShader(s)
        val st = IntArray(1)
        GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, st, 0)
        if (st[0] == 0) { fail("Shader compile: " + GLES20.glGetShaderInfoLog(s)); return null }
        return s
    }

    override fun onInputSurface(request: SurfaceRequest) {
        handler.post {
            try {
                if (!initGl()) { request.willNotProvideSurface(); return@post }
                val t = IntArray(1)
                GLES20.glGenTextures(1, t, 0)
                val texId = t[0]
                GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texId)
                GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
                GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
                val st = SurfaceTexture(texId)
                st.setDefaultBufferSize(request.resolution.width, request.resolution.height)
                val surface = Surface(st)
                st.setOnFrameAvailableListener({ draw(st, texId) }, handler)
                request.provideSurface(surface, executor) {
                    st.setOnFrameAvailableListener(null)
                    st.release(); surface.release()
                    GLES20.glDeleteTextures(1, intArrayOf(texId), 0)
                }
            } catch (e: Exception) { fail("Input: ${e.message}") }
        }
    }

    override fun onOutputSurface(output: SurfaceOutput) {
        handler.post {
            try {
                if (!initGl()) { output.close(); return@post }
                val surface = output.getSurface(executor) { _ ->
                    outputs.remove(output)?.let { EGL14.eglDestroySurface(dpy, it) }
                    output.close()
                }
                val es = EGL14.eglCreateWindowSurface(dpy, cfg, surface, intArrayOf(EGL14.EGL_NONE), 0)
                if (es == EGL14.EGL_NO_SURFACE) { fail("EGL window surface selhal"); return@post }
                outputs[output] = es
                AppleDebug.outputs = outputs.size
            } catch (e: Exception) { fail("Output: ${e.message}") }
        }
    }

    private fun draw(st: SurfaceTexture, texId: Int) {
        try {
            st.updateTexImage()
            st.getTransformMatrix(texMat)
            val ts = st.timestamp
            for ((out, es) in outputs) {
                EGL14.eglMakeCurrent(dpy, es, es, ctx)
                out.updateTransformMatrix(surfMat, texMat)
                GLES20.glViewport(0, 0, out.size.width, out.size.height)
                GLES20.glUseProgram(program)
                GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
                GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, texId)
                GLES20.glUniformMatrix4fv(uMat, 1, false, surfMat, 0)
                quad.position(0)
                GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 16, quad)
                GLES20.glEnableVertexAttribArray(aPos)
                quad.position(2)
                GLES20.glVertexAttribPointer(aTex, 2, GLES20.GL_FLOAT, false, 16, quad)
                GLES20.glEnableVertexAttribArray(aTex)
                GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
                EGLExt.eglPresentationTimeANDROID(dpy, es, ts)
                EGL14.eglSwapBuffers(dpy, es)
            }
            EGL14.eglMakeCurrent(dpy, pbuf, pbuf, ctx)
            AppleDebug.frames++
            val ge = GLES20.glGetError()
            if (ge != 0) AppleDebug.last = "GL chyba $ge"
        } catch (e: Exception) { Log.e("HyperCam", "draw: ${e.message}"); AppleDebug.last = "draw: ${e.message}" }
    }
}

/** Diagnostika efektu – ukáže se po stisku „i“. */
object AppleDebug {
    @Volatile var frames = 0L
    @Volatile var outputs = 0
    @Volatile var last = "-"
}
