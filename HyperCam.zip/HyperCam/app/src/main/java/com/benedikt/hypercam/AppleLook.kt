package com.benedikt.hypercam

import android.graphics.Bitmap
import java.util.stream.IntStream
import kotlin.math.roundToInt

/** Apple-like look: soft S-curve, lifted blacks, slight warmth, richer (not harsh) saturation. */
object AppleLook {
    private val lut = IntArray(256) { i ->
        val x = i / 255f
        var y = x + 0.45f * x * (1 - x) * (2 * x - 1)   // soft contrast
        y = 0.015f + y * 0.985f                          // gentle black lift
        (y.coerceIn(0f, 1f) * 255f).roundToInt()
    }

    fun apply(bmp: Bitmap): Bitmap {
        val out = if (bmp.isMutable) bmp else bmp.copy(Bitmap.Config.ARGB_8888, true)
        val w = out.width
        val h = out.height
        val band = 256
        val bands = (h + band - 1) / band
        // pruhy se počítají souběžně; samotné čtení/zápis pixelů je krátce zamčené
        IntStream.range(0, bands).parallel().forEach { bi ->
            val y = bi * band
            val hh = minOf(band, h - y)
            val px = IntArray(w * hh)
            synchronized(out) { out.getPixels(px, 0, w, 0, y, w, hh) }
            for (i in px.indices) {
                val p = px[i]
                var r = lut[(p shr 16) and 255].toFloat()
                var g = lut[(p shr 8) and 255].toFloat()
                var b = lut[p and 255].toFloat()
                val l = 0.299f * r + 0.587f * g + 0.114f * b
                r = (l + (r - l) * 1.12f) * 1.02f   // saturation + warm
                g = l + (g - l) * 1.12f
                b = (l + (b - l) * 1.12f) * 0.975f
                px[i] = (0xFF shl 24) or
                    (r.coerceIn(0f, 255f).toInt() shl 16) or
                    (g.coerceIn(0f, 255f).toInt() shl 8) or
                    b.coerceIn(0f, 255f).toInt()
            }
            synchronized(out) { out.setPixels(px, 0, w, 0, y, w, hh) }
        }
        return out
    }
}
