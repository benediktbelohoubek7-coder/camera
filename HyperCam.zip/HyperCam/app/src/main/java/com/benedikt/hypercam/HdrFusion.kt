package com.benedikt.hypercam

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import java.util.concurrent.Executor
import java.util.stream.IntStream
import kotlin.coroutines.resume
import kotlinx.coroutines.suspendCancellableCoroutine

/** Vyfotí jeden snímek a vrátí JPEG bajty + potřebné otočení (nebo null při chybě). */
suspend fun grabPhoto(ic: ImageCapture, exec: Executor): Pair<ByteArray, Int>? =
    suspendCancellableCoroutine { cont ->
        ic.takePicture(exec, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                val buf = image.planes[0].buffer
                val b = ByteArray(buf.remaining())
                buf.get(b)
                val r = image.imageInfo.rotationDegrees
                image.close()
                cont.resume(Pair(b, r))
            }

            override fun onError(e: ImageCaptureException) {
                cont.resume(null)
            }
        })
    }

/**
 * HDR skládáním expozic (exposure fusion): z několika snímků s různou expozicí se pro každý pixel
 * vezme to, co je dobře exponované. Váhy se počítají v nízkém rozlišení a vyhlazují, aby nevznikaly švy.
 * Výstup má nejvýš ~14 MP (kvůli paměti).
 */
object HdrFusion {
    fun fuse(jpegs: List<ByteArray>): Bitmap {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(jpegs[0], 0, jpegs[0].size, o)
        var s = 1
        while ((o.outWidth / s).toLong() * (o.outHeight / s) > 14_000_000L) s *= 2
        val bmps = jpegs.parallelStream().map {
            BitmapFactory.decodeByteArray(it, 0, it.size, BitmapFactory.Options().apply {
                inSampleSize = s; inMutable = true
            })
        }.collect(java.util.stream.Collectors.toList())
        val n = bmps.size
        val w = bmps[0].width
        val h = bmps[0].height

        // mapy vah v 1/8 rozlišení
        val gw = maxOf(2, w / 8)
        val gh = maxOf(2, h / 8)
        val wmap = Array(n) { FloatArray(gw * gh) }
        for (k in 0 until n) {
            val small = Bitmap.createScaledBitmap(bmps[k], gw, gh, true)
            val px = IntArray(gw * gh)
            small.getPixels(px, 0, gw, 0, 0, gw, gh)
            if (small !== bmps[k]) small.recycle()
            for (i in px.indices) {
                val p = px[i]
                val l = (0.299f * ((p shr 16) and 255) + 0.587f * ((p shr 8) and 255) + 0.114f * (p and 255)) / 255f
                val d = l - 0.5f
                wmap[k][i] = Math.exp((-d * d / 0.08).toDouble()).toFloat() + 1e-4f
            }
            blur(wmap[k], gw, gh, 3)
            blur(wmap[k], gw, gh, 3)
        }
        for (i in 0 until gw * gh) {
            var sum = 0f
            for (k in 0 until n) sum += wmap[k][i]
            for (k in 0 until n) wmap[k][i] /= sum
        }

        // samotné smíchání po pruzích; výsledek se zapisuje do prvního snímku
        val out = bmps[0]
        val band = 128
        IntStream.range(0, (h + band - 1) / band).parallel().forEach { bi ->
            val y0 = bi * band
            val hh = minOf(band, h - y0)
            val px = Array(n) { IntArray(w * hh) }
            for (k in 0 until n) synchronized(out) { bmps[k].getPixels(px[k], 0, w, 0, y0, w, hh) }
            val res = IntArray(w * hh)
            for (yy in 0 until hh) {
                val gy = ((y0 + yy) * (gh - 1).toFloat() / (h - 1)).coerceIn(0f, gh - 1f)
                val gy0 = gy.toInt()
                val gy1 = minOf(gy0 + 1, gh - 1)
                val fy = gy - gy0
                for (x in 0 until w) {
                    val gx = x * (gw - 1).toFloat() / (w - 1)
                    val gx0 = gx.toInt()
                    val gx1 = minOf(gx0 + 1, gw - 1)
                    val fx = gx - gx0
                    val idx = yy * w + x
                    var r = 0f
                    var g = 0f
                    var b = 0f
                    for (k in 0 until n) {
                        val m = wmap[k]
                        val wk = (m[gy0 * gw + gx0] * (1 - fx) + m[gy0 * gw + gx1] * fx) * (1 - fy) +
                            (m[gy1 * gw + gx0] * (1 - fx) + m[gy1 * gw + gx1] * fx) * fy
                        val p = px[k][idx]
                        r += wk * ((p shr 16) and 255)
                        g += wk * ((p shr 8) and 255)
                        b += wk * (p and 255)
                    }
                    res[idx] = (0xFF shl 24) or
                        (r.toInt().coerceIn(0, 255) shl 16) or
                        (g.toInt().coerceIn(0, 255) shl 8) or
                        b.toInt().coerceIn(0, 255)
                }
            }
            synchronized(out) { out.setPixels(res, 0, w, 0, y0, w, hh) }
        }
        for (k in 1 until n) bmps[k].recycle()
        return out
    }

    private fun blur(a: FloatArray, w: Int, h: Int, r: Int) {
        val t = FloatArray(a.size)
        for (y in 0 until h) for (x in 0 until w) {
            var s = 0f; var c = 0
            for (dx in -r..r) { val xx = x + dx; if (xx in 0 until w) { s += a[y * w + xx]; c++ } }
            t[y * w + x] = s / c
        }
        for (y in 0 until h) for (x in 0 until w) {
            var s = 0f; var c = 0
            for (dy in -r..r) { val yy = y + dy; if (yy in 0 until h) { s += t[yy * w + x]; c++ } }
            a[y * w + x] = s / c
        }
    }
}
