package com.benedikt.hypercam

import android.graphics.ImageFormat
import android.graphics.Rect
import android.graphics.YuvImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.zxing.BarcodeFormat
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.MultiFormatReader
import com.google.zxing.PlanarYUVLuminanceSource
import com.google.zxing.common.HybridBinarizer
import java.io.ByteArrayOutputStream

/**
 * Jeden analyzer pro dvě věci: čtení QR kódů (jen jasová rovina Y, ZXing)
 * a – když je zapnutý webcam režim – posílání snímků jako JPEG do WebcamServer.
 */
class QrAnalyzer(
    private val onFound: (String) -> Unit,
    private val webcam: () -> WebcamServer?
) : ImageAnalysis.Analyzer {
    private val reader = MultiFormatReader().apply {
        setHints(mapOf<DecodeHintType, Any>(
            DecodeHintType.POSSIBLE_FORMATS to listOf(BarcodeFormat.QR_CODE),
            DecodeHintType.TRY_HARDER to true))
    }
    private var last = 0L

    override fun analyze(image: ImageProxy) {
        try {
            webcam()?.push(toJpeg(image))
            val now = System.currentTimeMillis()
            if (now - last >= 350) { last = now; decode(image) }
        } catch (_: Exception) {
        } finally {
            image.close()
        }
    }

    private fun decode(image: ImageProxy) {
        try {
            val plane = image.planes[0]
            val buf = plane.buffer
            buf.rewind()
            val data = ByteArray(plane.rowStride * image.height)
            buf.get(data, 0, minOf(buf.remaining(), data.size))
            val src = PlanarYUVLuminanceSource(data, plane.rowStride, image.height, 0, 0, image.width, image.height, false)
            reader.decodeWithState(BinaryBitmap(HybridBinarizer(src))).text?.let(onFound)
        } catch (_: Exception) {
        } finally {
            reader.reset()
        }
    }

    /** YUV_420_888 -> NV21 -> JPEG (kvalita 85). */
    private fun toJpeg(image: ImageProxy): ByteArray {
        val w = image.width
        val h = image.height
        val out = ByteArray(w * h * 3 / 2)
        val yP = image.planes[0]
        val uP = image.planes[1]
        val vP = image.planes[2]
        val yBuf = yP.buffer
        if (yP.rowStride == w) {
            yBuf.rewind(); yBuf.get(out, 0, w * h)
        } else {
            for (r in 0 until h) { yBuf.position(r * yP.rowStride); yBuf.get(out, r * w, w) }
        }
        val uBuf = uP.buffer
        val vBuf = vP.buffer
        var o = w * h
        for (r in 0 until h / 2) {
            for (c in 0 until w / 2) {
                out[o++] = vBuf.get(r * vP.rowStride + c * vP.pixelStride)
                out[o++] = uBuf.get(r * uP.rowStride + c * uP.pixelStride)
            }
        }
        val bos = ByteArrayOutputStream(w * h / 4)
        YuvImage(out, ImageFormat.NV21, w, h, null).compressToJpeg(Rect(0, 0, w, h), 85, bos)
        return bos.toByteArray()
    }
}
