package com.benedikt.hypercam

import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.zxing.BarcodeFormat
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.MultiFormatReader
import com.google.zxing.PlanarYUVLuminanceSource
import com.google.zxing.common.HybridBinarizer

/** Čte QR kódy z živého náhledu (jen jasová rovina Y, ZXing). */
class QrAnalyzer(private val onFound: (String) -> Unit) : ImageAnalysis.Analyzer {
    private val reader = MultiFormatReader().apply {
        setHints(mapOf<DecodeHintType, Any>(
            DecodeHintType.POSSIBLE_FORMATS to listOf(BarcodeFormat.QR_CODE),
            DecodeHintType.TRY_HARDER to true))
    }
    private var last = 0L

    override fun analyze(image: ImageProxy) {
        val now = System.currentTimeMillis()
        if (now - last < 250) { image.close(); return }
        last = now
        try {
            val plane = image.planes[0]
            val buf = plane.buffer
            val data = ByteArray(plane.rowStride * image.height)
            buf.get(data, 0, minOf(buf.remaining(), data.size))
            val src = PlanarYUVLuminanceSource(data, plane.rowStride, image.height, 0, 0, image.width, image.height, false)
            val res = reader.decodeWithState(BinaryBitmap(HybridBinarizer(src)))
            res.text?.let(onFound)
        } catch (_: Exception) {
        } finally {
            reader.reset()
            image.close()
        }
    }
}
