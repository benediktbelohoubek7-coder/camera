package com.benedikt.hypercam

import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.atomic.AtomicInteger
import kotlin.concurrent.thread

/** Malý HTTP server: posílá snímky z kamery jako MJPEG stream (prohlížeč, OBS, VLC). */
class WebcamServer(private val port: Int = 8080) {
    @Volatile var running = false
        private set
    @Volatile private var server: ServerSocket? = null
    @Volatile private var frame: ByteArray? = null
    @Volatile private var seq = 0L
    val clients = AtomicInteger(0)

    fun start() {
        if (running) return
        running = true
        thread(name = "webcam-accept", isDaemon = true) {
            try {
                val ss = ServerSocket(port)
                server = ss
                while (running) {
                    val s = ss.accept()
                    thread(name = "webcam-client", isDaemon = true) { serve(s) }
                }
            } catch (_: Exception) {
            }
        }
    }

    fun stop() {
        running = false
        try { server?.close() } catch (_: Exception) {}
        server = null
    }

    fun push(jpeg: ByteArray) {
        frame = jpeg
        seq++
    }

    private fun serve(s: Socket) {
        try {
            s.tcpNoDelay = true
            val input = s.getInputStream().bufferedReader()
            val req = input.readLine() ?: return
            while (true) { val l = input.readLine(); if (l.isNullOrEmpty()) break }
            val path = req.split(" ").getOrNull(1) ?: "/"
            val out = s.getOutputStream()
            when {
                path.startsWith("/video") -> {
                    out.write(("HTTP/1.1 200 OK\r\nContent-Type: multipart/x-mixed-replace; boundary=frame\r\n" +
                        "Cache-Control: no-cache\r\nConnection: close\r\n\r\n").toByteArray())
                    clients.incrementAndGet()
                    try {
                        var last = -1L
                        while (running) {
                            val f = frame
                            val sq = seq
                            if (f != null && sq != last) {
                                last = sq
                                out.write("--frame\r\nContent-Type: image/jpeg\r\nContent-Length: ${f.size}\r\n\r\n".toByteArray())
                                out.write(f)
                                out.write("\r\n".toByteArray())
                                out.flush()
                            } else Thread.sleep(4)
                        }
                    } finally { clients.decrementAndGet() }
                }
                path.startsWith("/snapshot") -> {
                    val f = frame
                    if (f == null) out.write("HTTP/1.1 503 Service Unavailable\r\nConnection: close\r\n\r\n".toByteArray())
                    else {
                        out.write("HTTP/1.1 200 OK\r\nContent-Type: image/jpeg\r\nContent-Length: ${f.size}\r\nConnection: close\r\n\r\n".toByteArray())
                        out.write(f)
                    }
                    out.flush()
                }
                else -> {
                    val html = "<html><head><meta name=viewport content='width=device-width'><title>HyperCam</title></head>" +
                        "<body style='margin:0;background:#000'><img src='/video' style='width:100%;height:100vh;object-fit:contain'></body></html>"
                    val b = html.toByteArray()
                    out.write("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: ${b.size}\r\nConnection: close\r\n\r\n".toByteArray())
                    out.write(b)
                    out.flush()
                }
            }
        } catch (_: Exception) {
        } finally {
            try { s.close() } catch (_: Exception) {}
        }
    }
}

/** IPv4 adresy telefonu (Wi-Fi, USB tethering, hotspot). */
fun localIps(): List<String> = try {
    NetworkInterface.getNetworkInterfaces().toList()
        .filter { it.isUp && !it.isLoopback }
        .flatMap { ni -> ni.inetAddresses.toList().filterIsInstance<Inet4Address>().mapNotNull { it.hostAddress } }
} catch (e: Exception) {
    emptyList()
}
