package com.benedikt.hypercam

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import kotlin.math.abs

/** Mřížka 3×3 a vodováha ve stylu Apple: bílá čára se naklání, při vyrovnání zežloutne a srovná se. */
@Composable
fun CameraOverlay(grid: Boolean, level: Boolean, tiltProvider: () -> Float, flatProvider: () -> Boolean, aspect: Float) {
    Canvas(Modifier.fillMaxSize()) {
        val tilt = tiltProvider()   // čte se až při kreslení, ne při kompozici
        val flat = flatProvider()
        val w = size.width
        val h = size.height
        val ph = minOf(h, w * aspect)
        val top = (h - ph) / 2f
        val dp = 1.dp.toPx()

        if (grid) {
            val col = Color.White.copy(alpha = 0.35f)
            for (i in 1..2) {
                drawLine(col, Offset(w * i / 3f, top), Offset(w * i / 3f, top + ph), dp)
                drawLine(col, Offset(0f, top + ph * i / 3f), Offset(w, top + ph * i / 3f), dp)
            }
        }

        if (level && !flat) {
            val c = Offset(w / 2f, h / 2f)
            val ok = abs(tilt) < 1.2f
            val main = if (ok) Color(0xFFFFC400) else Color.White.copy(alpha = 0.85f)
            val ref = if (ok) Color(0xFFFFC400) else Color.White.copy(alpha = 0.5f)
            val sw = 2 * dp
            for (sgn in listOf(-1f, 1f)) {   // pevné značky po stranách
                drawLine(ref, Offset(c.x + sgn * 96 * dp, c.y), Offset(c.x + sgn * 120 * dp, c.y), sw, StrokeCap.Round)
            }
            rotate(if (ok) 0f else -tilt, c) {   // naklápěcí čára
                drawLine(main, Offset(c.x - 84 * dp, c.y), Offset(c.x + 84 * dp, c.y), sw, StrokeCap.Round)
            }
        }
    }
}
