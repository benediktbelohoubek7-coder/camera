package com.benedikt.hypercam

import android.content.Context
import android.hardware.camera2.CameraCharacteristics as C
import android.hardware.camera2.CameraManager
import android.media.MediaRecorder

/** Text dump of what each camera really exposes (level, 10-bit, video sizes, focal lengths). */
object CameraCaps {
    fun dump(ctx: Context): String {
        val m = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val sb = StringBuilder()
        for (id in m.cameraIdList) {
            val c = m.getCameraCharacteristics(id)
            val facing = if (c.get(C.LENS_FACING) == C.LENS_FACING_BACK) "back" else "front/other"
            val level = when (c.get(C.INFO_SUPPORTED_HARDWARE_LEVEL)) {
                C.INFO_SUPPORTED_HARDWARE_LEVEL_LEGACY -> "LEGACY"
                C.INFO_SUPPORTED_HARDWARE_LEVEL_LIMITED -> "LIMITED"
                C.INFO_SUPPORTED_HARDWARE_LEVEL_FULL -> "FULL"
                C.INFO_SUPPORTED_HARDWARE_LEVEL_3 -> "LEVEL_3"
                else -> "EXTERNAL"
            }
            val caps = c.get(C.REQUEST_AVAILABLE_CAPABILITIES)?.toList() ?: emptyList()
            val tenBit = caps.contains(18) // DYNAMIC_RANGE_TEN_BIT
            val raw = caps.contains(C.REQUEST_AVAILABLE_CAPABILITIES_RAW)
            val phys = c.physicalCameraIds.joinToString()
            val focal = c.get(C.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.joinToString()
            val ois = (c.get(C.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)?.size ?: 0) > 1
            val vid = c.get(C.SCALER_STREAM_CONFIGURATION_MAP)
                ?.getOutputSizes(MediaRecorder::class.java)
                ?.sortedByDescending { it.width * it.height }?.take(4)
                ?.joinToString { "${it.width}x${it.height}" }
            val fps = c.get(C.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)?.maxByOrNull { it.upper }
            sb.append("ID $id [$facing] $level\n")
            sb.append("  10-bit: $tenBit | RAW: $raw | OIS: $ois\n")
            sb.append("  focal: $focal | physical: $phys\n")
            sb.append("  video: $vid | max fps: ${fps?.upper}\n\n")
        }
        return sb.toString()
    }
}
