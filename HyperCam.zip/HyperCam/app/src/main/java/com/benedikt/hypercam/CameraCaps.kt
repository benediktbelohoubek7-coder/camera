package com.benedikt.hypercam

import android.app.ActivityManager
import android.content.Context
import android.graphics.ImageFormat
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCharacteristics as C
import android.hardware.camera2.CameraManager
import android.hardware.display.DisplayManager
import android.media.MediaCodecList
import android.media.MediaRecorder
import android.os.Build
import android.os.PowerManager
import android.view.Display
import java.io.File
import kotlin.math.roundToInt

/** Text dump telefonu a všech kamer (pro ladění): SoC, jádra, paměť, kodeky, možnosti kamer. */
object CameraCaps {
    private val CAP_NAMES = mapOf(
        0 to "BACKWARD_COMPATIBLE", 1 to "MANUAL_SENSOR", 2 to "MANUAL_POST_PROCESSING", 3 to "RAW",
        4 to "PRIVATE_REPROCESSING", 5 to "READ_SENSOR_SETTINGS", 6 to "BURST_CAPTURE",
        7 to "YUV_REPROCESSING", 8 to "DEPTH_OUTPUT", 9 to "CONSTRAINED_HIGH_SPEED_VIDEO",
        11 to "LOGICAL_MULTI_CAMERA", 12 to "MONOCHROME", 16 to "ULTRA_HIGH_RESOLUTION_SENSOR",
        17 to "REMOSAIC_REPROCESSING", 18 to "DYNAMIC_RANGE_TEN_BIT", 19 to "STREAM_USE_CASE",
        20 to "COLOR_SPACE_PROFILES"
    )

    private fun ints(a: IntArray?): String = a?.joinToString() ?: "-"

    private fun sizes(arr: Array<android.util.Size>?, n: Int = 3): String =
        arr?.sortedByDescending { it.width.toLong() * it.height }?.take(n)
            ?.joinToString { "${it.width}x${it.height}" } ?: "-"

    fun dump(ctx: Context): String {
        val sb = StringBuilder()

        // ---------- telefon ----------
        sb.append("== TELEFON ==\n")
        sb.append("Model: ${Build.MANUFACTURER} ${Build.MODEL} (${Build.DEVICE})\n")
        sb.append("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n")
        sb.append("Build: ${Build.DISPLAY}\n")
        val soc = if (Build.VERSION.SDK_INT >= 31) "${Build.SOC_MANUFACTURER} ${Build.SOC_MODEL}" else Build.HARDWARE
        sb.append("SoC: $soc | ABI: ${Build.SUPPORTED_ABIS.joinToString()}\n")
        val n = Runtime.getRuntime().availableProcessors()
        val freqs = (0 until n).joinToString { i ->
            try {
                (File("/sys/devices/system/cpu/cpu$i/cpufreq/cpuinfo_max_freq").readText().trim().toLong() / 1000).toString()
            } catch (e: Exception) { "?" }
        }
        sb.append("Jádra: $n | max MHz po jádrech: $freqs\n")
        try {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            sb.append("RAM: ${mi.totalMem / 1048576} MB celkem, ${mi.availMem / 1048576} MB volné | heap ${am.memoryClass}/${am.largeMemoryClass} MB\n")
        } catch (e: Exception) { sb.append("RAM: ?\n") }
        try {
            val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
            sb.append("Thermal status: ${pm.currentThermalStatus} (0 = v pořádku)\n")
        } catch (e: Exception) { }
        try {
            val d = (ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).getDisplay(Display.DEFAULT_DISPLAY)
            sb.append("Displej: ${ctx.resources.displayMetrics.widthPixels}x${ctx.resources.displayMetrics.heightPixels}, " +
                "${d.refreshRate.roundToInt()} Hz | režimy: ${d.supportedModes.joinToString { "${it.refreshRate.roundToInt()}" }}\n")
        } catch (e: Exception) { }

        // ---------- video kodeky ----------
        sb.append("\n== VIDEO KODEKY (enkodér) ==\n")
        try {
            val list = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos
            for (t in listOf("video/avc", "video/hevc")) {
                for (ci in list.filter { it.isEncoder && it.supportedTypes.any { s -> s.equals(t, true) } }) {
                    val vc = ci.getCapabilitiesForType(t).videoCapabilities
                    val fps4k = try { vc.getSupportedFrameRatesFor(3840, 2160).upper.roundToInt().toString() } catch (e: Exception) { "-" }
                    sb.append("$t ${ci.name} hw=${ci.isHardwareAccelerated} max=${vc.supportedWidths.upper}x${vc.supportedHeights.upper} " +
                        "bitrate<=${vc.bitrateRange.upper / 1_000_000}Mb/s fps@4K<=$fps4k\n")
                }
            }
        } catch (e: Exception) { sb.append("(kodeky se nepodařilo zjistit)\n") }

        // ---------- kamery ----------
        sb.append("\n== KAMERY ==\n")
        val m = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        sb.append("Dostupná ID: ${m.cameraIdList.joinToString()}\n")
        for (id in m.cameraIdList) {
            try {
                val c = m.getCameraCharacteristics(id)
                val facing = if (c.get(C.LENS_FACING) == C.LENS_FACING_BACK) "back" else "front/other"
                val level = when (c.get(C.INFO_SUPPORTED_HARDWARE_LEVEL)) {
                    C.INFO_SUPPORTED_HARDWARE_LEVEL_LEGACY -> "LEGACY"
                    C.INFO_SUPPORTED_HARDWARE_LEVEL_LIMITED -> "LIMITED"
                    C.INFO_SUPPORTED_HARDWARE_LEVEL_FULL -> "FULL"
                    C.INFO_SUPPORTED_HARDWARE_LEVEL_3 -> "LEVEL_3"
                    else -> "EXTERNAL"
                }
                sb.append("\nID $id [$facing] $level\n")
                val caps = c.get(C.REQUEST_AVAILABLE_CAPABILITIES)?.toList() ?: emptyList()
                sb.append("  Capabilities: ${caps.joinToString { CAP_NAMES[it] ?: it.toString() }}\n")
                sb.append("  Fyzické kamery: ${c.physicalCameraIds.joinToString().ifEmpty { "-" }}\n")
                sb.append("  Ohnisko: ${c.get(C.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.joinToString() ?: "-"} | " +
                    "min. ostření: ${c.get(C.LENS_INFO_MINIMUM_FOCUS_DISTANCE)} | clona: ${c.get(C.LENS_INFO_AVAILABLE_APERTURES)?.joinToString() ?: "-"}\n")
                sb.append("  Senzor: pole ${c.get(C.SENSOR_INFO_PIXEL_ARRAY_SIZE)}, velikost ${c.get(C.SENSOR_INFO_PHYSICAL_SIZE)} mm\n")
                sb.append("  ISO: ${c.get(C.SENSOR_INFO_SENSITIVITY_RANGE)} | expozice ns: ${c.get(C.SENSOR_INFO_EXPOSURE_TIME_RANGE)}\n")
                sb.append("  EV: ${c.get(C.CONTROL_AE_COMPENSATION_RANGE)} po ${c.get(C.CONTROL_AE_COMPENSATION_STEP)}\n")
                if (Build.VERSION.SDK_INT >= 30) sb.append("  Zoom: ${c.get(C.CONTROL_ZOOM_RATIO_RANGE)}\n")
                sb.append("  FPS rozsahy: ${c.get(C.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)?.joinToString { "${it.lower}-${it.upper}" } ?: "-"}\n")
                sb.append("  OIS módy: ${ints(c.get(C.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION))} | " +
                    "video stabilizace: ${ints(c.get(C.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES))}\n")
                sb.append("  NR módy: ${ints(c.get(C.NOISE_REDUCTION_AVAILABLE_NOISE_REDUCTION_MODES))} | " +
                    "hrany: ${ints(c.get(C.EDGE_AVAILABLE_EDGE_MODES))} | scény: ${ints(c.get(C.CONTROL_AVAILABLE_SCENE_MODES))}\n")
                if (Build.VERSION.SDK_INT >= 33) {
                    val p = c.get(C.REQUEST_AVAILABLE_DYNAMIC_RANGE_PROFILES)?.supportedProfiles
                    sb.append("  Dynamic range profily: ${p?.joinToString() ?: "-"}\n")
                }
                val map = c.get(C.SCALER_STREAM_CONFIGURATION_MAP)
                sb.append("  JPEG: ${sizes(map?.getOutputSizes(ImageFormat.JPEG))}\n")
                sb.append("  YUV: ${sizes(map?.getOutputSizes(ImageFormat.YUV_420_888))}\n")
                sb.append("  Náhled: ${sizes(map?.getOutputSizes(SurfaceTexture::class.java))}\n")
                sb.append("  Video (MediaRecorder): ${sizes(map?.getOutputSizes(MediaRecorder::class.java), 4)}\n")
            } catch (e: Exception) {
                sb.append("ID $id: chyba ${e.message}\n")
            }
        }
        sb.append("\n")
        return sb.toString()
    }
}
