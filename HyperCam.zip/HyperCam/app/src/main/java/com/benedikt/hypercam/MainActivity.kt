package com.benedikt.hypercam

import android.Manifest
import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Size
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.concurrent.futures.await
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

private val Yellow = Color(0xFFFFC400)
private val Red = Color(0xFFFF3B30)
private val Panel = Color(0xB3121212)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var ok by remember { mutableStateOf(false) }
            val req = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
                ok = it[Manifest.permission.CAMERA] == true
            }
            LaunchedEffect(Unit) { req.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)) }
            if (ok) CameraScreen()
        }
    }
}

private fun fmtZoom(z: Float): String = when {
    z < 1f -> "%.1f".format(Locale.US, z).removePrefix("0")
    abs(z - z.roundToInt()) < 0.05f -> "${z.roundToInt()}"
    else -> "%.1f".format(Locale.US, z)
}

@Composable
fun CameraScreen() {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    val exec = remember { ContextCompat.getMainExecutor(ctx) }
    val main = remember { Handler(Looper.getMainLooper()) }
    fun toast(m: String) { main.post { Toast.makeText(ctx, m, Toast.LENGTH_LONG).show() } }

    var mode by remember { mutableIntStateOf(0) }            // 0 foto, 1 video
    var zoom by remember { mutableFloatStateOf(1f) }
    var flash by remember { mutableIntStateOf(0) }           // 0 vyp, 1 auto, 2 zap/svítí
    var rec by remember { mutableStateOf<Recording?>(null) }
    var seconds by remember { mutableIntStateOf(0) }
    var camera by remember { mutableStateOf<Camera?>(null) }
    var info by remember { mutableStateOf<String?>(null) }
    var showSettings by remember { mutableStateOf(false) }
    var quality4k by remember { mutableStateOf(true) }
    var appleLook by remember { mutableStateOf(true) }
    val isRec = rec != null

    val preview = remember { PreviewView(ctx).apply { scaleType = PreviewView.ScaleType.FIT_CENTER } }
    val imageCapture = remember {
        ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
            .setResolutionSelector(
                ResolutionSelector.Builder().setResolutionStrategy(
                    ResolutionStrategy(Size(4000, 3000), ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER)
                ).build()
            ).build()
    }
    val recorder = remember(quality4k) {
        Recorder.Builder()
            .setQualitySelector(QualitySelector.fromOrderedList(
                if (quality4k) listOf(Quality.UHD, Quality.FHD) else listOf(Quality.FHD, Quality.HD),
                FallbackStrategy.lowerQualityOrHigherThan(Quality.HD)))
            .setTargetVideoEncodingBitRate(if (quality4k) 50_000_000 else 25_000_000)
            .build()
    }
    val videoCapture = remember(recorder) { VideoCapture.withOutput(recorder) }
    val appleEffect = remember { createAppleEffect { toast(it) } }

    LaunchedEffect(mode, videoCapture, appleLook) {
        val provider = ProcessCameraProvider.getInstance(ctx).await()
        provider.unbindAll()
        val pv = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
        camera = try {
            if (mode == 0) {
                provider.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, pv, imageCapture)
            } else {
                val group = UseCaseGroup.Builder().addUseCase(pv).addUseCase(videoCapture)
                    .apply { if (appleLook) addEffect(appleEffect) }.build()
                provider.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, group)
            }
        } catch (e: Exception) {
            toast("Kamera: ${e.message}")
            if (mode == 1 && appleLook) appleLook = false   // záloha: video bez efektu
            null
        }
        zoom = 1f
    }

    // blesk: foto = flashMode, video = svítilna
    LaunchedEffect(camera, flash, mode) {
        imageCapture.flashMode = when (flash) {
            1 -> ImageCapture.FLASH_MODE_AUTO
            2 -> ImageCapture.FLASH_MODE_ON
            else -> ImageCapture.FLASH_MODE_OFF
        }
        camera?.cameraControl?.enableTorch(mode == 1 && flash != 0)
    }

    // časovač nahrávání
    LaunchedEffect(isRec) {
        seconds = 0
        while (isRec) { delay(1000); seconds++ }
    }

    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        initialValue = 1f, targetValue = 0.25f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "a"
    )

    fun minZoom() = camera?.cameraInfo?.zoomState?.value?.minZoomRatio ?: 1f
    fun maxZoom() = (camera?.cameraInfo?.zoomState?.value?.maxZoomRatio ?: 5f).coerceIn(2f, 10f)
    fun setZoom(z: Float) {
        val v = z.coerceIn(minZoom(), maxZoom())
        zoom = v; camera?.cameraControl?.setZoomRatio(v)
    }

    fun shoot() {
        imageCapture.takePicture(exec, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                scope.launch {
                    withContext(Dispatchers.Default) {
                        val rot = image.imageInfo.rotationDegrees
                        var bmp = image.toBitmap(); image.close()
                        if (rot != 0) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height,
                            Matrix().apply { postRotate(rot.toFloat()) }, true)
                        val out = if (appleLook) AppleLook.apply(bmp) else bmp
                        val cv = ContentValues().apply {
                            put(MediaStore.Images.Media.DISPLAY_NAME, "HC_${System.currentTimeMillis()}.jpg")
                            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/HyperCam")
                        }
                        ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)?.let { u ->
                            ctx.contentResolver.openOutputStream(u)?.use { out.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                        }
                    }
                }
            }
            override fun onError(e: ImageCaptureException) { toast("Foto: ${e.message}") }
        })
    }

    fun toggleRec() {
        val cur = rec
        if (cur != null) { cur.stop(); rec = null; return }
        val cv = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "HC_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/HyperCam")
        }
        val opts = MediaStoreOutputOptions.Builder(ctx.contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(cv).build()
        rec = recorder.prepareRecording(ctx, opts).withAudioEnabled().start(exec) { ev ->
            if (ev is VideoRecordEvent.Finalize && ev.hasError()) toast("Video: chyba ${ev.error}")
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView({ preview }, Modifier.fillMaxSize().pointerInput(Unit) {
            detectTransformGestures { _, _, z, _ -> if (z != 1f) setZoom(zoom * z) }
        })

        if (isRec) Box(Modifier.fillMaxSize().border(3.dp, Red.copy(alpha = pulse), RoundedCornerShape(0.dp)))

        // horní lišta: nastavení + blesk | čas | info
        Box(Modifier.align(Alignment.TopCenter).fillMaxWidth().statusBarsPadding().padding(16.dp)) {
            Row(Modifier.align(Alignment.CenterStart), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill("⚙", enabled = !isRec) { showSettings = true }
                if (camera?.cameraInfo?.hasFlashUnit() == true) {
                    val label = if (mode == 0) listOf("⚡ Vyp", "⚡ Auto", "⚡ Zap")[flash]
                                else if (flash == 0) "🔦 Vyp" else "🔦 Svítí"
                    Pill(label, selected = flash != 0) {
                        flash = if (mode == 0) (flash + 1) % 3 else if (flash == 0) 2 else 0
                    }
                }
            }
            if (mode == 1) {
                Row(
                    Modifier.align(Alignment.Center).clip(CircleShape)
                        .background(if (isRec) Red else Color(0x66000000))
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (isRec) {
                        Box(Modifier.size(10.dp).alpha(pulse).clip(CircleShape).background(Color.White))
                        Spacer(Modifier.width(8.dp))
                    }
                    val t = if (seconds >= 3600) "%d:%02d:%02d".format(seconds / 3600, seconds % 3600 / 60, seconds % 60)
                            else "%02d:%02d".format(seconds / 60, seconds % 60)
                    Text(t, color = Color.White, fontSize = 18.sp)
                }
            }
            Box(Modifier.align(Alignment.CenterEnd)) { Pill("i") { info = CameraCaps.dump(ctx) + "Apple efekt: snímků=${AppleDebug.frames}, výstupů=${AppleDebug.outputs}, chyba=${AppleDebug.last}" } }
        }

        // spodní panel
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding()
                .padding(12.dp).clip(RoundedCornerShape(32.dp))
                .background(Panel).padding(vertical = 14.dp, horizontal = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            ZoomSelector(zoom, minZoom(), maxZoom()) { setZoom(it) }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(28.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Foto", color = if (mode == 0) Yellow else Color.White, fontSize = 15.sp,
                    modifier = Modifier.alpha(if (isRec) 0.4f else 1f).clickable(enabled = !isRec) { mode = 0 })
                Text("Video", color = if (mode == 1) Yellow else Color.White, fontSize = 15.sp,
                    modifier = Modifier.alpha(if (isRec) 0.4f else 1f).clickable(enabled = !isRec) {
                        mode = 1; if (flash == 1) flash = 0
                    })
            }
            Spacer(Modifier.height(14.dp))
            Box(
                Modifier.size(78.dp)
                    .border(4.dp, if (isRec) Red.copy(alpha = pulse.coerceAtLeast(0.5f)) else Color.White, CircleShape)
                    .clickable { if (mode == 0) shoot() else toggleRec() },
                contentAlignment = Alignment.Center
            ) {
                Box(
                    Modifier.size(if (isRec) 30.dp else 62.dp)
                        .clip(if (isRec) RoundedCornerShape(8.dp) else CircleShape)
                        .background(if (mode == 1) Red else Color.White)
                )
            }
        }
    }

    if (showSettings) {
        AlertDialog(
            onDismissRequest = { showSettings = false },
            confirmButton = { TextButton({ showSettings = false }) { Text("Hotovo") } },
            title = { Text("Nastavení") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text("Kvalita videa", fontSize = 14.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Pill("4K", selected = quality4k, dark = true) { quality4k = true }
                        Pill("1080p", selected = !quality4k, dark = true) { quality4k = false }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Apple barvy (foto i video)", Modifier.weight(1f), fontSize = 14.sp)
                        Switch(appleLook, { appleLook = it })
                    }
                }
            }
        )
    }

    info?.let {
        AlertDialog(onDismissRequest = { info = null }, confirmButton = { TextButton({ info = null }) { Text("OK") } },
            title = { Text("Kamery") }, text = { Text(it, fontSize = 12.sp) })
    }
}

/** Výběr zoomu ve stylu Xiaomi: kolečka .6 | 1 | 2 | 5, vybrané svítí žlutě a ukazuje aktuální zoom. */
@Composable
fun ZoomSelector(zoom: Float, minZ: Float, maxZ: Float, onPick: (Float) -> Unit) {
    val presets = buildList {
        if (minZ < 0.95f) add(minZ)
        add(1f); add(2f); add(5f)
    }.filter { it <= maxZ + 0.01f }
    val selected = presets.lastOrNull { it <= zoom + 0.05f } ?: presets.first()
    Row(
        Modifier.clip(CircleShape).background(Color(0x66000000)).padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically
    ) {
        presets.forEach { p ->
            val sel = p == selected
            Box(
                Modifier.size(if (sel) 44.dp else 36.dp).clip(CircleShape)
                    .background(if (sel) Color(0xCC000000) else Color.Transparent)
                    .clickable { onPick(p) },
                contentAlignment = Alignment.Center
            ) {
                Text(if (sel) fmtZoom(zoom) + "×" else fmtZoom(p),
                    color = if (sel) Yellow else Color.White, fontSize = if (sel) 14.sp else 13.sp)
            }
        }
    }
}

@Composable
fun Pill(label: String, selected: Boolean = false, enabled: Boolean = true, dark: Boolean = false, onClick: () -> Unit) {
    Box(
        Modifier.alpha(if (enabled) 1f else 0.4f).clip(CircleShape)
            .background(if (selected) Yellow else if (dark) Color(0x22000000) else Color(0x66000000))
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) { Text(label, color = if (selected) Color.Black else if (dark) Color.Gray else Color.White, fontSize = 14.sp) }
}
