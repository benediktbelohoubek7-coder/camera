package com.benedikt.hypercam

import android.Manifest
import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Bundle
import android.provider.MediaStore
import android.util.Size
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.concurrent.futures.await
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Yellow = Color(0xFFFFC400)
private val Red = Color(0xFFFF3B30)
private val Panel = Color(0xB3121212)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var ok by remember { mutableStateOf(false) }
            val req = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
                ok = it[Manifest.permission.CAMERA] == true
            }
            LaunchedEffect(Unit) { req.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)) }
            if (ok) CameraScreen()
        }
    }
}

@Composable
fun CameraScreen() {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    val exec = remember { ContextCompat.getMainExecutor(ctx) }

    var mode by remember { mutableIntStateOf(0) }            // 0 foto, 1 video
    var zoom by remember { mutableFloatStateOf(1f) }
    var rec by remember { mutableStateOf<Recording?>(null) }
    var seconds by remember { mutableIntStateOf(0) }
    var camera by remember { mutableStateOf<Camera?>(null) }
    var info by remember { mutableStateOf<String?>(null) }
    var showSettings by remember { mutableStateOf(false) }
    var quality4k by remember { mutableStateOf(true) }
    var appleLook by remember { mutableStateOf(true) }
    val isRec = rec != null

    val preview = remember { PreviewView(ctx).apply { scaleType = PreviewView.ScaleType.FIT_CENTER } }
    val imageCapture = remember {
        ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
            .setResolutionSelector(
                ResolutionSelector.Builder().setResolutionStrategy(
                    ResolutionStrategy(Size(4000, 3000), ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER)
                ).build()
            ).build()
    }
    val recorder = remember(quality4k) {
        Recorder.Builder()
            .setQualitySelector(QualitySelector.fromOrderedList(
                if (quality4k) listOf(Quality.UHD, Quality.FHD) else listOf(Quality.FHD, Quality.HD),
                FallbackStrategy.lowerQualityOrHigherThan(Quality.HD)))
            .setTargetVideoEncodingBitRate(if (quality4k) 50_000_000 else 25_000_000)
            .build()
    }
    val videoCapture = remember(recorder) { VideoCapture.withOutput(recorder) }

    LaunchedEffect(mode, videoCapture) {
        val provider = ProcessCameraProvider.getInstance(ctx).await()
        provider.unbindAll()
        val pv = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
        camera = provider.bindToLifecycle(
            owner, CameraSelector.DEFAULT_BACK_CAMERA, pv,
            if (mode == 0) imageCapture else videoCapture
        )
        zoom = 1f
    }

    // časovač nahrávání
    LaunchedEffect(isRec) {
        seconds = 0
        while (isRec) { delay(1000); seconds++ }
    }

    // pulzování
    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        initialValue = 1f, targetValue = 0.25f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "a"
    )

    fun setZoom(z: Float) { zoom = z; camera?.cameraControl?.setZoomRatio(z) }

    fun shoot() {
        imageCapture.takePicture(exec, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                scope.launch {
                    withContext(Dispatchers.Default) {
                        val rot = image.imageInfo.rotationDegrees
                        var bmp = image.toBitmap(); image.close()
                        if (rot != 0) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height,
                            Matrix().apply { postRotate(rot.toFloat()) }, true)
                        val out = if (appleLook) AppleLook.apply(bmp) else bmp
                        val cv = ContentValues().apply {
                            put(MediaStore.Images.Media.DISPLAY_NAME, "HC_${System.currentTimeMillis()}.jpg")
                            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/HyperCam")
                        }
                        ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)?.let { u ->
                            ctx.contentResolver.openOutputStream(u)?.use { out.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                        }
                    }
                }
            }
            override fun onError(e: ImageCaptureException) {}
        })
    }

    fun toggleRec() {
        val cur = rec
        if (cur != null) { cur.stop(); rec = null; return }
        val cv = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "HC_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/HyperCam")
        }
        val opts = MediaStoreOutputOptions.Builder(ctx.contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(cv).build()
        rec = recorder.prepareRecording(ctx, opts).withAudioEnabled().start(exec) {}
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView({ preview }, Modifier.fillMaxSize())

        // červený rámeček kolem celé obrazovky při nahrávání
        if (isRec) Box(Modifier.fillMaxSize().border(3.dp, Red.copy(alpha = pulse), RoundedCornerShape(0.dp)))

        // horní lišta: nastavení | čas nahrávání | info
        Box(Modifier.align(Alignment.TopCenter).fillMaxWidth().statusBarsPadding().padding(16.dp)) {
            Box(Modifier.align(Alignment.CenterStart)) { Pill("⚙", enabled = !isRec) { showSettings = true } }
            if (isRec) {
                Row(
                    Modifier.align(Alignment.Center).clip(CircleShape).background(Red)
                        .padding(horizontal = 14.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(10.dp).alpha(pulse).clip(CircleShape).background(Color.White))
                    Spacer(Modifier.width(8.dp))
                    Text("%02d:%02d".format(seconds / 60, seconds % 60), color = Color.White, fontSize = 16.sp)
                }
            }
            Box(Modifier.align(Alignment.CenterEnd)) { Pill("i") { info = CameraCaps.dump(ctx) } }
        }

        // spodní HyperOS panel
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding()
                .padding(12.dp).clip(RoundedCornerShape(32.dp))
                .background(Panel).padding(vertical = 14.dp, horizontal = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // zoom: hodnota + plynulý slider + rychlé volby
            val maxZoom = (camera?.cameraInfo?.zoomState?.value?.maxZoomRatio ?: 5f).coerceIn(2f, 10f)
            Text("%.1f×".format(zoom), color = Yellow, fontSize = 15.sp)
            Slider(
                value = zoom.coerceIn(1f, maxZoom), onValueChange = { setZoom(it) },
                valueRange = 1f..maxZoom,
                colors = SliderDefaults.colors(thumbColor = Yellow, activeTrackColor = Yellow,
                    inactiveTrackColor = Color(0x55FFFFFF))
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf(1f, 2f, 5f).filter { it <= maxZoom }.forEach { z ->
                    Pill(if (z == 1f) "1×" else "${z.toInt()}×", selected = zoom == z) { setZoom(z) }
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(28.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Foto", color = if (mode == 0) Yellow else Color.White, fontSize = 15.sp,
                    modifier = Modifier.alpha(if (isRec) 0.4f else 1f).clickable(enabled = !isRec) { mode = 0 })
                Text("Video", color = if (mode == 1) Yellow else Color.White, fontSize = 15.sp,
                    modifier = Modifier.alpha(if (isRec) 0.4f else 1f).clickable(enabled = !isRec) { mode = 1 })
            }
            Spacer(Modifier.height(14.dp))
            // spoušť: při nahrávání pulzující červený kroužek + červený čtverec
            Box(
                Modifier.size(78.dp)
                    .border(4.dp, if (isRec) Red.copy(alpha = pulse.coerceAtLeast(0.5f)) else Color.White, CircleShape)
                    .clickable { if (mode == 0) shoot() else toggleRec() },
                contentAlignment = Alignment.Center
            ) {
                Box(
                    Modifier.size(if (isRec) 30.dp else 62.dp)
                        .clip(if (isRec) RoundedCornerShape(8.dp) else CircleShape)
                        .background(if (mode == 1) Red else Color.White)
                )
            }
        }
    }

    if (showSettings) {
        AlertDialog(
            onDismissRequest = { showSettings = false },
            confirmButton = { TextButton({ showSettings = false }) { Text("Hotovo") } },
            title = { Text("Nastavení") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text("Kvalita videa", fontSize = 14.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Pill("4K", selected = quality4k, dark = true) { quality4k = true }
                        Pill("1080p", selected = !quality4k, dark = true) { quality4k = false }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Apple barvy u fotek", Modifier.weight(1f), fontSize = 14.sp)
                        Switch(appleLook, { appleLook = it })
                    }
                }
            }
        )
    }

    info?.let {
        AlertDialog(onDismissRequest = { info = null }, confirmButton = { TextButton({ info = null }) { Text("OK") } },
            title = { Text("Kamery") }, text = { Text(it, fontSize = 12.sp) })
    }
}

@Composable
fun Pill(label: String, selected: Boolean = false, enabled: Boolean = true, dark: Boolean = false, onClick: () -> Unit) {
    Box(
        Modifier.alpha(if (enabled) 1f else 0.4f).clip(CircleShape)
            .background(if (selected) Yellow else if (dark) Color(0x22000000) else Color(0x66000000))
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) { Text(label, color = if (selected) Color.Black else if (dark) Color.Gray else Color.White, fontSize = 14.sp) }
}
