package com.benedikt.hypercam

import android.Manifest
import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.os.Bundle
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.content.pm.PackageManager
import android.os.Handler
import android.os.SystemClock
import java.util.concurrent.Executors
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlin.math.atan2
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.KeyEvent
import androidx.compose.ui.graphics.graphicsLayer
import android.content.ContentUris
import android.content.Context
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureRequest
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import kotlin.math.pow
import android.os.Looper
import android.provider.MediaStore
import android.util.Size
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.concurrent.futures.await
import androidx.core.content.ContextCompat
import androidx.exifinterface.media.ExifInterface
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

private val Yellow = Color(0xFFFFC400)
private val Red = Color(0xFFFF3B30)
private val Panel = Color(0xB3121212)

class MainActivity : ComponentActivity() {
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if ((keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) && ShutterBus.handler != null) {
            if (event.repeatCount == 0) ShutterBus.handler?.invoke()
            return true   // hlasitost se nemění, tlačítka slouží jako spoušť
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if ((keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) && ShutterBus.handler != null)
            return true
        return super.onKeyUp(keyCode, event)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ProcessCameraProvider.getInstance(this)   // rozjede inicializaci CameraX hned, souběžně s UI
        val hasCam = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        val hasMic = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        setContent {
            var ok by remember { mutableStateOf(hasCam) }
            val req = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
                ok = it[Manifest.permission.CAMERA] == true
            }
            LaunchedEffect(Unit) {
                if (!hasCam || !hasMic) req.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
            }
            if (ok) CameraScreen()
        }
    }
}

private fun fmtZoom(z: Float): String = when {
    z < 1f -> "%.1f".format(Locale.US, z).removePrefix("0")
    abs(z - z.roundToInt()) < 0.05f -> "${z.roundToInt()}"
    else -> "%.1f".format(Locale.US, z)
}

@Composable
fun CameraScreen() {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    val exec = remember { ContextCompat.getMainExecutor(ctx) }
    val main = remember { Handler(Looper.getMainLooper()) }
    fun toast(m: String) { main.post { Toast.makeText(ctx, m, Toast.LENGTH_LONG).show() } }

    var mode by remember { mutableIntStateOf(0) }            // 0 foto, 1 video
    var zoom by remember { mutableFloatStateOf(1f) }
    var flash by remember { mutableIntStateOf(0) }           // 0 vyp, 1 auto, 2 zap/svítí
    var rec by remember { mutableStateOf<Recording?>(null) }
    var seconds by remember { mutableIntStateOf(0) }
    var camera by remember { mutableStateOf<Camera?>(null) }
    var lensBack by remember { mutableStateOf(true) }
    var resumeRec by remember { mutableStateOf(false) }
    var last by remember { mutableStateOf<LastMedia?>(null) }
    var thumb by remember { mutableStateOf<Bitmap?>(null) }
    var refresh by remember { mutableIntStateOf(0) }
    var flipTurn by remember { mutableIntStateOf(0) }
    val flipRot by animateFloatAsState(flipTurn * 180f, tween(350), label = "flip")
    var showGrid by remember { mutableStateOf(false) }
    var showLevel by remember { mutableStateOf(true) }
    var tilt by remember { mutableFloatStateOf(0f) }
    var flat by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf<String?>(null) }
    var showSettings by remember { mutableStateOf(false) }
    var quality4k by remember { mutableStateOf(true) }
    var appleLook by remember { mutableStateOf(true) }
    val isRec = rec != null

    // Pro režim: ruční ISO / závěrka / EV / ostření / vyvážení bílé
    var proTab by remember { mutableIntStateOf(0) }
    var manualExp by remember { mutableStateOf(false) }
    var isoV by remember { mutableFloatStateOf(0.3f) }
    var shutV by remember { mutableFloatStateOf(0.55f) }
    var evIdx by remember { mutableIntStateOf(0) }
    var manualFocus by remember { mutableStateOf(false) }
    var focusV by remember { mutableFloatStateOf(0f) }
    var wb by remember { mutableIntStateOf(0) }
    val caps = remember(camera) { camera?.let { proCaps(it) } }
    val isoVal = caps?.let { (it.isoMin * (it.isoMax.toFloat() / it.isoMin).pow(isoV)).roundToInt() } ?: 100
    val shutNs = caps?.let { (it.expMin * (it.expMax.toDouble() / it.expMin).pow(shutV.toDouble())).toLong() } ?: 16_000_000L
    val shutSec = shutNs / 1e9
    val shutText = if (shutSec >= 0.5) "%.1fs".format(Locale.US, shutSec) else "1/${(1 / shutSec).roundToInt()}"
    val evText = if (caps == null) "0" else "%+.1f".format(Locale.US, evIdx * caps.evStep)
    val focusText = if (focusV <= 0.01f || caps == null || caps.minFocus <= 0f) "∞"
                    else "${(100f / (focusV * caps.minFocus)).roundToInt()} cm"

    // QR: čte se automaticky ve foto režimu, nic se nepřepíná
    var qr by remember { mutableStateOf<String?>(null) }
    var qrAt by remember { mutableLongStateOf(0L) }
    var qrDialog by remember { mutableStateOf<String?>(null) }
    val analysisExec = remember { Executors.newSingleThreadExecutor() }
    val analysis = remember {
        ImageAnalysis.Builder()
            .setResolutionSelector(ResolutionSelector.Builder().setResolutionStrategy(
                ResolutionStrategy(Size(1280, 720), ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER)).build())
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .build().also { a ->
                a.setAnalyzer(analysisExec, QrAnalyzer { t -> main.post { qr = t; qrAt = SystemClock.uptimeMillis() } })
            }
    }
    LaunchedEffect(qrAt) { delay(2500); qr = null }   // ikonka zmizí, když kód 2,5 s nevidíme

    fun openQr(t: String) {
        val linkRe = Regex("^(https?|tel|mailto|sms|geo):", RegexOption.IGNORE_CASE)
        val target = when {
            linkRe.containsMatchIn(t) -> t
            t.startsWith("www.", ignoreCase = true) -> "https://$t"
            else -> null
        }
        if (target == null) { qrDialog = t; return }
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(target)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { qrDialog = t }
    }

    val preview = remember { PreviewView(ctx).apply { scaleType = PreviewView.ScaleType.FIT_CENTER } }
    val imageCapture = remember {
        ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
            .setResolutionSelector(
                ResolutionSelector.Builder()
                    .setResolutionStrategy(ResolutionStrategy.HIGHEST_AVAILABLE_STRATEGY)
                    .setAllowedResolutionMode(ResolutionSelector.PREFER_HIGHER_RESOLUTION_OVER_CAPTURE_RATE)
                    .setResolutionFilter { sizes, _ ->
                        sizes.filter { it.width.toLong() * it.height <= 52_000_000L }
                            .sortedByDescending { it.width.toLong() * it.height }
                    }
                    .build()
            ).build()
    }
    val recorder = remember(quality4k) {
        Recorder.Builder()
            .setQualitySelector(
                if (quality4k) QualitySelector.from(Quality.HIGHEST)
                else QualitySelector.fromOrderedList(listOf(Quality.FHD, Quality.HD),
                    FallbackStrategy.lowerQualityOrHigherThan(Quality.HD)))
            .setTargetVideoEncodingBitRate(if (quality4k) 100_000_000 else 40_000_000)
            .build()
    }
    val videoCapture = remember(recorder) { VideoCapture.withOutput(recorder) }
    val appleEffect = remember { createAppleEffect { toast(it) } }

    LaunchedEffect(mode == 1, if (mode == 1) videoCapture else null, mode == 1 && appleLook, lensBack) {
        val provider = ProcessCameraProvider.getInstance(ctx).await()
        provider.unbindAll()
        val sel = if (lensBack) CameraSelector.DEFAULT_BACK_CAMERA else CameraSelector.DEFAULT_FRONT_CAMERA
        val pv = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
        camera = try {
            if (mode != 1) {
                try {
                    provider.bindToLifecycle(owner, sel, pv, imageCapture, analysis)
                } catch (e: Exception) {   // záloha: bez čtení QR
                    provider.unbindAll()
                    provider.bindToLifecycle(owner, sel, pv, imageCapture)
                }
            } else {
                val group = UseCaseGroup.Builder().addUseCase(pv).addUseCase(videoCapture)
                    .apply { if (appleLook) addEffect(appleEffect) }.build()
                provider.bindToLifecycle(owner, sel, group)
            }
        } catch (e: Exception) {
            toast("Kamera: ${e.message}")
            if (mode == 1 && appleLook) appleLook = false   // záloha: video bez efektu
            null
        }
        zoom = 1f
    }

    // blesk: foto = flashMode, video = svítilna
    LaunchedEffect(camera, flash, mode) {
        imageCapture.flashMode = when (flash) {
            1 -> ImageCapture.FLASH_MODE_AUTO
            2 -> ImageCapture.FLASH_MODE_ON
            else -> ImageCapture.FLASH_MODE_OFF
        }
        camera?.cameraControl?.enableTorch(mode == 1 && flash != 0)
    }

    // Pro: aplikace ručních hodnot (mimo Pro se vše vrací na auto)
    LaunchedEffect(camera, mode, manualExp, isoVal, shutNs, manualFocus, focusV, wb) {
        val cam = camera ?: return@LaunchedEffect
        if (mode == 2) applyPro(cam, manualExp, isoVal, shutNs, manualFocus, focusV * (caps?.minFocus ?: 0f), WB[wb].second)
        else clearPro(cam)
    }
    LaunchedEffect(camera, mode, evIdx) {
        camera?.cameraControl?.setExposureCompensationIndex(if (mode == 2) evIdx else 0)
    }

    // časovač nahrávání
    LaunchedEffect(isRec) {
        seconds = 0
        while (isRec) { delay(1000); seconds++ }
    }

    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        initialValue = 1f, targetValue = 0.25f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "a"
    )

    fun minZoom() = camera?.cameraInfo?.zoomState?.value?.minZoomRatio ?: 1f
    fun maxZoom() = (camera?.cameraInfo?.zoomState?.value?.maxZoomRatio ?: 5f).coerceIn(2f, 10f)
    fun setZoom(z: Float) {
        val v = z.coerceIn(minZoom(), maxZoom())
        zoom = v; camera?.cameraControl?.setZoomRatio(v)
    }

    val stopFlag = remember { BooleanArray(1) }

    fun shoot() {
        imageCapture.takePicture(exec, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                val rot = image.imageInfo.rotationDegrees
                val buf = image.planes[0].buffer
                val bytes = ByteArray(buf.remaining()); buf.get(bytes)
                image.close()
                scope.launch {
                    withContext(Dispatchers.Default) {
                        val cv = ContentValues().apply {
                            put(MediaStore.Images.Media.DISPLAY_NAME, "HC_${System.currentTimeMillis()}.jpg")
                            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/HyperCam")
                        }
                        val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
                            ?: return@withContext
                        ctx.contentResolver.openOutputStream(uri)?.use { os ->
                            if (appleLook) {
                                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size,
                                    BitmapFactory.Options().apply { inMutable = true })
                                AppleLook.apply(bmp).compress(Bitmap.CompressFormat.JPEG, 100, os)
                                bmp.recycle()
                            } else os.write(bytes)
                        }
                        // otočení přes EXIF (bez dalších kopií obrázku v paměti)
                        ctx.contentResolver.openFileDescriptor(uri, "rw")?.use { pfd ->
                            val ex = ExifInterface(pfd.fileDescriptor)
                            ex.setAttribute(ExifInterface.TAG_ORIENTATION,
                                when (rot) { 90 -> "6"; 180 -> "3"; 270 -> "8"; else -> "1" })
                            ex.saveAttributes()
                        }
                        main.post { refresh++ }
                    }
                }
            }
            override fun onError(e: ImageCaptureException) { toast("Foto: ${e.message}") }
        })
    }

    fun startRec(retries: Int) {
        val cv = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "HC_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/HyperCam")
        }
        val opts = MediaStoreOutputOptions.Builder(ctx.contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(cv).build()
        stopFlag[0] = false
        val holder = arrayOfNulls<Recording>(1)
        val r = recorder.prepareRecording(ctx, opts).withAudioEnabled().start(exec) { ev ->
            if (ev is VideoRecordEvent.Finalize) {
                val mine = rec === holder[0]
                val noData = ev.error == VideoRecordEvent.Finalize.ERROR_NO_VALID_DATA
                if (noData && mine && !stopFlag[0] && retries > 0) {
                    // první start ještě nedostal žádné snímky – zkusíme to samy znovu
                    seconds = 0
                    main.postDelayed({ if (rec != null && !stopFlag[0]) startRec(retries - 1) }, 400)
                } else {
                    if (ev.hasError() && (mine || noData)) toast(if (noData) "Video je příliš krátké" else "Video: chyba ${ev.error}")
                    if (mine) rec = null
                    main.postDelayed({ refresh++ }, 500)
                }
            }
        }
        holder[0] = r
        rec = r
    }

    fun toggleRec() {
        val cur = rec
        if (cur != null) { stopFlag[0] = true; cur.stop(); rec = null; return }
        startRec(2)
    }

    fun switchCamera() {
        val cur = rec
        if (cur != null) {          // během natáčení: uložíme klip a hned začneme nový na druhé kameře
            resumeRec = true; stopFlag[0] = true; cur.stop(); rec = null
        }
        if (lensBack) flash = 0
        lensBack = !lensBack
    }

    LaunchedEffect(camera) {
        if (resumeRec && camera != null) {
            resumeRec = false
            delay(800)
            if (mode == 1) startRec(2)
        }
    }

    fun openGallery() {
        val l = last
        try {
            val i = if (l != null)
                Intent(Intent.ACTION_VIEW).setDataAndType(l.uri, if (l.isVideo) "video/*" else "image/*")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            else Intent(Intent.ACTION_VIEW, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { toast("Galerie: ${e.message}") }
    }

    LaunchedEffect(refresh) {
        withContext(Dispatchers.IO) {
            val l = lastMedia(ctx)
            last = l
            thumb = l?.let { runCatching { ctx.contentResolver.loadThumbnail(it.uri, Size(256, 256), null) }.getOrNull() }
        }
    }

    fun buzz(effect: Int) {
        try { ctx.getSystemService(Vibrator::class.java)?.vibrate(VibrationEffect.createPredefined(effect)) }
        catch (_: Exception) {}
    }

    // jedna spoušť pro displej i tlačítka hlasitosti
    fun shutterPress() {
        if (mode != 1) { buzz(VibrationEffect.EFFECT_CLICK); shoot() }
        else {
            buzz(if (isRec) VibrationEffect.EFFECT_DOUBLE_CLICK else VibrationEffect.EFFECT_HEAVY_CLICK)
            toggleRec()
        }
    }
    SideEffect { ShutterBus.handler = { shutterPress() } }
    DisposableEffect(Unit) { onDispose { ShutterBus.handler = null } }

    // vodováha: akcelerometr s vyhlazením, běží jen když je appka na očích
    DisposableEffect(owner, showLevel) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val acc = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        var sx = 0f; var sy = 9.8f; var sz = 0f
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                sx += 0.15f * (e.values[0] - sx)
                sy += 0.15f * (e.values[1] - sy)
                sz += 0.15f * (e.values[2] - sz)
                var d = atan2(-sx, sy) * 180f / Math.PI.toFloat()
                while (d > 45f) d -= 90f
                while (d < -45f) d += 90f
                if (abs(d - tilt) > 0.15f) tilt = d
                val f = abs(sz) > 8.3f
                if (f != flat) flat = f
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }
        var on = false
        fun start() { if (!on && acc != null && showLevel) { sm.registerListener(l, acc, SensorManager.SENSOR_DELAY_UI); on = true } }
        fun stop() { if (on) { sm.unregisterListener(l); on = false } }
        val obs = LifecycleEventObserver { _, ev ->
            if (ev == Lifecycle.Event.ON_RESUME) start() else if (ev == Lifecycle.Event.ON_PAUSE) stop()
        }
        owner.lifecycle.addObserver(obs)
        if (owner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) start()
        onDispose { owner.lifecycle.removeObserver(obs); stop() }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView({ preview }, Modifier.fillMaxSize().pointerInput(Unit) {
            detectTransformGestures { _, _, z, _ -> if (z != 1f) setZoom(zoom * z) }
        })

        CameraOverlay(showGrid, showLevel, { tilt }, { flat }, if (mode == 1) 16f / 9f else 4f / 3f)

        if (isRec) Box(Modifier.fillMaxSize().graphicsLayer { alpha = pulse }.border(3.dp, Red, RoundedCornerShape(0.dp)))

        // horní lišta: nastavení + blesk | čas | info
        Box(Modifier.align(Alignment.TopCenter).fillMaxWidth().statusBarsPadding().padding(16.dp)) {
            Row(Modifier.align(Alignment.CenterStart), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill("⚙", enabled = !isRec) { showSettings = true }
                if (camera?.cameraInfo?.hasFlashUnit() == true) {
                    val label = if (mode != 1) listOf("⚡ Vyp", "⚡ Auto", "⚡ Zap")[flash]
                                else if (flash == 0) "🔦 Vyp" else "🔦 Svítí"
                    Pill(label, selected = flash != 0) {
                        flash = if (mode != 1) (flash + 1) % 3 else if (flash == 0) 2 else 0
                    }
                }
            }
            if (mode == 1) {
                Row(
                    Modifier.align(Alignment.Center).clip(CircleShape)
                        .background(if (isRec) Red else Color(0x66000000))
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (isRec) {
                        Box(Modifier.size(10.dp).graphicsLayer { alpha = pulse }.clip(CircleShape).background(Color.White))
                        Spacer(Modifier.width(8.dp))
                    }
                    val t = if (seconds >= 3600) "%d:%02d:%02d".format(seconds / 3600, seconds % 3600 / 60, seconds % 60)
                            else "%02d:%02d".format(seconds / 60, seconds % 60)
                    Text(t, color = Color.White, fontSize = 18.sp)
                }
            }
            Box(Modifier.align(Alignment.CenterEnd)) { Pill("i") { info = CameraCaps.dump(ctx) + "Apple efekt: snímků=${AppleDebug.frames}, výstupů=${AppleDebug.outputs}, chyba=${AppleDebug.last}" } }
        }

        // QR ikonka nad spodním panelem
        qr?.let { t ->
            if (mode != 1) Box(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = if (mode == 2) 440.dp else 290.dp)) {
                Pill("▦  " + t.removePrefix("https://").removePrefix("http://").take(30), selected = true) { openQr(t) }
            }
        }

        // spodní panel
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding()
                .padding(12.dp).clip(RoundedCornerShape(32.dp))
                .background(Panel).padding(vertical = 14.dp, horizontal = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            ZoomSelector(zoom, minZoom(), maxZoom()) { setZoom(it) }
            Spacer(Modifier.height(14.dp))
            if (mode == 2) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ProChip("ISO", if (manualExp) "$isoVal" else "A", proTab == 0, Modifier.weight(1f)) { proTab = 0 }
                    ProChip("S", if (manualExp) shutText else "A", proTab == 1, Modifier.weight(1f)) { proTab = 1 }
                    ProChip("EV", evText, proTab == 2, Modifier.weight(1f)) { proTab = 2 }
                    ProChip("MF", if (manualFocus) focusText else "A", proTab == 3, Modifier.weight(1f)) { proTab = 3 }
                    ProChip("WB", WB[wb].first, proTab == 4, Modifier.weight(1f)) { proTab = 4 }
                }
                Spacer(Modifier.height(8.dp))
                val sc = SliderDefaults.colors(thumbColor = Yellow, activeTrackColor = Yellow,
                    inactiveTrackColor = Color(0x55FFFFFF))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    when (proTab) {
                        0 -> Slider(isoV, { isoV = it; manualExp = true }, Modifier.weight(1f), colors = sc)
                        1 -> Slider(shutV, { shutV = it; manualExp = true }, Modifier.weight(1f), colors = sc)
                        2 -> if (caps != null && caps.evMax > caps.evMin)
                            Slider(evIdx.toFloat(), { evIdx = it.roundToInt() }, Modifier.weight(1f),
                                enabled = !manualExp,
                                valueRange = caps.evMin.toFloat()..caps.evMax.toFloat(),
                                steps = caps.evMax - caps.evMin - 1, colors = sc)
                        else Text("EV tahle kamera nepodporuje", color = Color.White, fontSize = 13.sp,
                            modifier = Modifier.weight(1f))
                        3 -> if (caps != null && caps.minFocus > 0f)
                            Slider(focusV, { focusV = it; manualFocus = true }, Modifier.weight(1f), colors = sc)
                        else Text("Tahle kamera má pevné ostření", color = Color.White, fontSize = 13.sp,
                            modifier = Modifier.weight(1f))
                        else -> Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            WB.forEachIndexed { i, w -> Pill(w.first, selected = wb == i) { wb = i } }
                        }
                    }
                    if (proTab != 4) {
                        Spacer(Modifier.width(8.dp))
                        Pill("Auto") {
                            when (proTab) {
                                0, 1 -> manualExp = false
                                2 -> evIdx = 0
                                3 -> manualFocus = false
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(28.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Foto", color = if (mode == 0) Yellow else Color.White, fontSize = 15.sp,
                    modifier = Modifier.alpha(if (isRec) 0.4f else 1f).clickable(enabled = !isRec) { mode = 0 })
                Text("Video", color = if (mode == 1) Yellow else Color.White, fontSize = 15.sp,
                    modifier = Modifier.alpha(if (isRec) 0.4f else 1f).clickable(enabled = !isRec) {
                        mode = 1; if (flash == 1) flash = 0
                    })
                Text("Pro", color = if (mode == 2) Yellow else Color.White, fontSize = 15.sp,
                    modifier = Modifier.alpha(if (isRec) 0.4f else 1f).clickable(enabled = !isRec) { mode = 2 })
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(52.dp).clip(CircleShape).background(Color(0x33FFFFFF)).clickable { flipTurn++; switchCamera() },
                    contentAlignment = Alignment.Center) {
                    SwitchCamIcon(Modifier.size(26.dp).graphicsLayer { rotationZ = flipRot })
                }
            Box(
                Modifier.size(78.dp)
                    .drawBehind {
                        val sw = 4.dp.toPx()
                        drawCircle(if (isRec) Red.copy(alpha = pulse.coerceAtLeast(0.5f)) else Color.White,
                            radius = size.minDimension / 2 - sw / 2, style = Stroke(sw))
                    }
                    .clickable { shutterPress() },
                contentAlignment = Alignment.Center
            ) {
                Box(
                    Modifier.size(if (isRec) 30.dp else 62.dp)
                        .clip(if (isRec) RoundedCornerShape(8.dp) else CircleShape)
                        .background(if (mode == 1) Red else Color.White)
                )
            }
                val gShape = RoundedCornerShape(14.dp)
                Box(Modifier.size(52.dp).clip(gShape).background(Color(0x33FFFFFF))
                    .border(1.dp, Color(0x66FFFFFF), gShape).clickable { openGallery() }) {
                    thumb?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
                }
            }
        }
    }

    if (showSettings) {
        AlertDialog(
            onDismissRequest = { showSettings = false },
            confirmButton = { TextButton({ showSettings = false }) { Text("Hotovo") } },
            title = { Text("Nastavení") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text("Kvalita videa", fontSize = 14.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Pill("Nejvyšší", selected = quality4k, dark = true) { quality4k = true }
                        Pill("1080p", selected = !quality4k, dark = true) { quality4k = false }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Apple barvy (foto i video)", Modifier.weight(1f), fontSize = 14.sp)
                        Switch(appleLook, { appleLook = it })
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Vodováha", Modifier.weight(1f), fontSize = 14.sp)
                        Switch(showLevel, { showLevel = it })
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Mřížka", Modifier.weight(1f), fontSize = 14.sp)
                        Switch(showGrid, { showGrid = it })
                    }
                }
            }
        )
    }

    qrDialog?.let { t ->
        AlertDialog(
            onDismissRequest = { qrDialog = null },
            confirmButton = { TextButton({
                (ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as ClipboardManager)
                    .setPrimaryClip(ClipData.newPlainText("QR", t))
                qrDialog = null
            }) { Text("Kopírovat") } },
            dismissButton = { TextButton({ qrDialog = null }) { Text("Zavřít") } },
            title = { Text("QR kód") }, text = { Text(t) }
        )
    }

    info?.let {
        AlertDialog(onDismissRequest = { info = null }, confirmButton = { TextButton({ info = null }) { Text("OK") } },
            title = { Text("Kamery") }, text = { Text(it, fontSize = 12.sp) })
    }
}

/** Výběr zoomu ve stylu Xiaomi: kolečka .6 | 1 | 2 | 5, vybrané svítí žlutě a ukazuje aktuální zoom. */
@Composable
fun ZoomSelector(zoom: Float, minZ: Float, maxZ: Float, onPick: (Float) -> Unit) {
    val presets = buildList {
        if (minZ < 0.95f) add(minZ)
        add(1f); add(2f); add(5f)
    }.filter { it <= maxZ + 0.01f }
    val selected = presets.lastOrNull { it <= zoom + 0.05f } ?: presets.first()
    Row(
        Modifier.clip(CircleShape).background(Color(0x66000000)).padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically
    ) {
        presets.forEach { p ->
            val sel = p == selected
            Box(
                Modifier.size(if (sel) 44.dp else 36.dp).clip(CircleShape)
                    .background(if (sel) Color(0xCC000000) else Color.Transparent)
                    .clickable { onPick(p) },
                contentAlignment = Alignment.Center
            ) {
                Text(if (sel) fmtZoom(zoom) + "×" else fmtZoom(p),
                    color = if (sel) Yellow else Color.White, fontSize = if (sel) 14.sp else 13.sp)
            }
        }
    }
}

@Composable
fun Pill(label: String, selected: Boolean = false, enabled: Boolean = true, dark: Boolean = false, onClick: () -> Unit) {
    Box(
        Modifier.alpha(if (enabled) 1f else 0.4f).clip(CircleShape)
            .background(if (selected) Yellow else if (dark) Color(0x22000000) else Color(0x66000000))
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) { Text(label, color = if (selected) Color.Black else if (dark) Color.Gray else Color.White, fontSize = 14.sp) }
}

private val WB = listOf(
    "Auto" to CaptureRequest.CONTROL_AWB_MODE_AUTO,
    "Žárovka" to CaptureRequest.CONTROL_AWB_MODE_INCANDESCENT,
    "Zářivka" to CaptureRequest.CONTROL_AWB_MODE_FLUORESCENT,
    "Denní" to CaptureRequest.CONTROL_AWB_MODE_DAYLIGHT,
    "Zataženo" to CaptureRequest.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT,
    "Stín" to CaptureRequest.CONTROL_AWB_MODE_SHADE
)

data class ProCaps(
    val isoMin: Int, val isoMax: Int, val expMin: Long, val expMax: Long,
    val minFocus: Float, val evMin: Int, val evMax: Int, val evStep: Float
)

@androidx.annotation.OptIn(ExperimentalCamera2Interop::class)
fun proCaps(cam: Camera): ProCaps {
    val ci = Camera2CameraInfo.from(cam.cameraInfo)
    val iso = ci.getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
    val exp = ci.getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
    val ev = cam.cameraInfo.exposureState
    return ProCaps(
        isoMin = iso?.lower ?: 100,
        isoMax = minOf(iso?.upper ?: 3200, 6400),
        expMin = maxOf(exp?.lower ?: 125_000L, 125_000L),
        expMax = minOf(exp?.upper ?: 1_000_000_000L, 1_000_000_000L),
        minFocus = ci.getCameraCharacteristic(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f,
        evMin = ev.exposureCompensationRange.lower,
        evMax = ev.exposureCompensationRange.upper,
        evStep = ev.exposureCompensationStep.toFloat()
    )
}

@androidx.annotation.OptIn(ExperimentalCamera2Interop::class)
fun applyPro(cam: Camera, manualExp: Boolean, iso: Int, expNs: Long, manualFocus: Boolean, focusDiopter: Float, awb: Int) {
    val b = CaptureRequestOptions.Builder()
    if (manualExp) {
        b.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
        b.setCaptureRequestOption(CaptureRequest.SENSOR_SENSITIVITY, iso)
        b.setCaptureRequestOption(CaptureRequest.SENSOR_EXPOSURE_TIME, expNs)
        b.setCaptureRequestOption(CaptureRequest.SENSOR_FRAME_DURATION, maxOf(expNs, 33_333_333L))
    }
    if (manualFocus) {
        b.setCaptureRequestOption(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
        b.setCaptureRequestOption(CaptureRequest.LENS_FOCUS_DISTANCE, focusDiopter)
    }
    b.setCaptureRequestOption(CaptureRequest.CONTROL_AWB_MODE, awb)
    Camera2CameraControl.from(cam.cameraControl).setCaptureRequestOptions(b.build())
}

@androidx.annotation.OptIn(ExperimentalCamera2Interop::class)
fun clearPro(cam: Camera) {
    Camera2CameraControl.from(cam.cameraControl).clearCaptureRequestOptions()
}

@Composable
fun ProChip(label: String, value: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Column(
        modifier.clip(shape)
            .background(if (selected) Color(0x33FFC400) else Color(0x33FFFFFF))
            .border(1.dp, if (selected) Yellow else Color.Transparent, shape)
            .clickable(onClick = onClick).padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(label, color = Color(0xAAFFFFFF), fontSize = 10.sp)
        Text(value, color = if (selected) Yellow else Color.White, fontSize = 13.sp, maxLines = 1)
    }
}

data class LastMedia(val uri: Uri, val isVideo: Boolean, val ts: Long)

/** Poslední foto/video, které vyfotila tahle appka (složky Pictures/HyperCam a Movies/HyperCam). */
fun lastMedia(ctx: Context): LastMedia? {
    fun q(base: Uri, vid: Boolean): LastMedia? = ctx.contentResolver.query(
        base, arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DATE_ADDED),
        "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?",
        arrayOf(if (vid) "Movies/HyperCam%" else "Pictures/HyperCam%"),
        "${MediaStore.MediaColumns.DATE_ADDED} DESC"
    )?.use { c ->
        if (c.moveToFirst()) LastMedia(ContentUris.withAppendedId(base, c.getLong(0)), vid, c.getLong(1)) else null
    }
    return listOfNotNull(
        q(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, false),
        q(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true)
    ).maxByOrNull { it.ts }
}

/** Most mezi Activity (tlačítka hlasitosti) a spouští v Compose. */
object ShutterBus {
    @Volatile var handler: (() -> Unit)? = null
}
