package com.benedikt.hypercam

import android.Manifest
import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Bundle
import android.provider.MediaStore
import android.util.Size
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.*
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.concurrent.futures.await
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var ok by remember { mutableStateOf(false) }
            val req = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
                ok = it[Manifest.permission.CAMERA] == true
            }
            LaunchedEffect(Unit) { req.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)) }
            if (ok) CameraScreen()
        }
    }
}

@Composable
fun CameraScreen() {
    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()
    val exec = remember { ContextCompat.getMainExecutor(ctx) }
    var mode by remember { mutableIntStateOf(0) }          // 0 foto, 1 video
    var zoom by remember { mutableFloatStateOf(1f) }
    var rec by remember { mutableStateOf<Recording?>(null) }
    var camera by remember { mutableStateOf<Camera?>(null) }
    var info by remember { mutableStateOf<String?>(null) }

    val preview = remember { PreviewView(ctx).apply { scaleType = PreviewView.ScaleType.FIT_CENTER } }
    val imageCapture = remember {
        ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
            .setResolutionSelector(
                ResolutionSelector.Builder().setResolutionStrategy(
                    ResolutionStrategy(Size(4000, 3000), ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER)
                ).build()
            ).build()
    }
    val recorder = remember {
        Recorder.Builder()
            .setQualitySelector(QualitySelector.fromOrderedList(
                listOf(Quality.UHD, Quality.FHD),
                FallbackStrategy.lowerQualityOrHigherThan(Quality.FHD)))
            .setTargetVideoEncodingBitRate(50_000_000)
            .build()
    }
    val videoCapture = remember { VideoCapture.withOutput(recorder) }

    LaunchedEffect(mode) {
        val provider = ProcessCameraProvider.getInstance(ctx).await()
        provider.unbindAll()
        val pv = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
        camera = provider.bindToLifecycle(
            owner, CameraSelector.DEFAULT_BACK_CAMERA, pv,
            if (mode == 0) imageCapture else videoCapture
        )
        zoom = 1f
    }

    fun shoot() {
        imageCapture.takePicture(exec, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                scope.launch {
                    withContext(Dispatchers.Default) {
                        val rot = image.imageInfo.rotationDegrees
                        var bmp = image.toBitmap(); image.close()
                        if (rot != 0) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height,
                            Matrix().apply { postRotate(rot.toFloat()) }, true)
                        val out = AppleLook.apply(bmp)
                        val cv = ContentValues().apply {
                            put(MediaStore.Images.Media.DISPLAY_NAME, "HC_${System.currentTimeMillis()}.jpg")
                            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/HyperCam")
                        }
                        ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)?.let { u ->
                            ctx.contentResolver.openOutputStream(u)?.use { out.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                        }
                    }
                }
            }
            override fun onError(e: ImageCaptureException) {}
        })
    }

    fun toggleRec() {
        val cur = rec
        if (cur != null) { cur.stop(); rec = null; return }
        val cv = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "HC_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/HyperCam")
        }
        val opts = MediaStoreOutputOptions.Builder(ctx.contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(cv).build()
        rec = recorder.prepareRecording(ctx, opts).withAudioEnabled().start(exec) {}
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView({ preview }, Modifier.fillMaxSize())

        // horní lišta
        Row(Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(16.dp)) {
            Pill("i") { info = CameraCaps.dump(ctx) }
        }

        // spodní HyperOS panel
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding()
                .padding(12.dp).clip(RoundedCornerShape(32.dp))
                .background(Color(0x99121212)).padding(vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf(1f, 2f, 5f).forEach { z ->
                    Pill(if (z == 1f) "1×" else "${z.toInt()}×", selected = zoom == z) {
                        zoom = z; camera?.cameraControl?.setZoomRatio(z)
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(28.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Foto", color = if (mode == 0) Color(0xFFFFC400) else Color.White, fontSize = 15.sp,
                    modifier = Modifier.clickable(enabled = rec == null) { mode = 0 })
                Text("Video", color = if (mode == 1) Color(0xFFFFC400) else Color.White, fontSize = 15.sp,
                    modifier = Modifier.clickable(enabled = rec == null) { mode = 1 })
            }
            Spacer(Modifier.height(14.dp))
            val inner = if (mode == 1) Color(0xFFFF3B30) else Color.White
            Box(
                Modifier.size(78.dp).border(4.dp, Color.White, CircleShape).padding(7.dp)
                    .clip(if (rec != null) RoundedCornerShape(14.dp) else CircleShape)
                    .background(inner)
                    .clickable { if (mode == 0) shoot() else toggleRec() }
            )
        }
    }

    info?.let {
        AlertDialog(onDismissRequest = { info = null }, confirmButton = { TextButton({ info = null }) { Text("OK") } },
            title = { Text("Kamery") }, text = { Text(it, fontSize = 12.sp) })
    }
}

@Composable
fun Pill(label: String, selected: Boolean = false, onClick: () -> Unit) {
    Box(
        Modifier.clip(CircleShape)
            .background(if (selected) Color(0xFFFFC400) else Color(0x66000000))
            .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) { Text(label, color = if (selected) Color.Black else Color.White, fontSize = 14.sp) }
}
