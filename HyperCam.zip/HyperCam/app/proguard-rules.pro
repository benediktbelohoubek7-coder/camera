# CameraX, Compose a ZXing si pravidla nesou samy.
-allowaccessmodification
-repackageclasses ''
