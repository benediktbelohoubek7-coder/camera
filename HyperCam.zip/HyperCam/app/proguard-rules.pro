# CameraX, Compose a ZXing si pravidla nesou samy. Nic dalšího netřeba.
